# Add it up!

# Complete each step below according to the challenge directions and
# include it in this file. Also make sure everything that isn't code
# is commented in the file.

# I worked on this challenge [by myself, with: ].

# 0. total Pseudocode
# make sure all pseudocode is commented out!

# Input: an array of numbers (integers or floats)
# Output: a number (integer or float)
# Steps to solve the problem:
# 0 -> Define a method that takes an array as a parameter
# 1 -> count the number of objects in the array
# 2 -> if the array is not empty, add objects in the array
# 3 -> Else return nil


# 1. total initial solution

def total(array)
  # array.reduce 0, :+
  # array.inject(:+)
  # array.map(&:to_i).reduce(:+)
  # array.inject {|item_in_the_array,x| item_in_the_array+x}
end

def sentence_maker(a_single_argument)
  items  = a_single_argument.count.to_i
  output = a_single_argument.values_at(0..(items-1)).join(" ").capitalize
  return output + "."
end

# 3. total refactored solution


# 4. sentence_maker pseudocode
# make sure all pseudocode is commented out!
# Input:
# Output:
# Steps to solve the problem.


# 5. sentence_maker initial solution



# 6. sentence_maker refactored solution

