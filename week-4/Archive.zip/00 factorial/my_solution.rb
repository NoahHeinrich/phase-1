# Factorial

# I worked on this challenge [by myself, with: ].


# Your Solution Below
def factorial(number)
  if number < 0
    return nil
  end
  if number <= 1
    1
  else
    number * factorial(number-1)
  end
end

# or the elegant way
def factorial(number)
if number <= 1
    1
  else
  number.downto(1).reduce(:*)
  end
end

# or the each way
def factorial(number)
  total = 1
  (1..number).each do |n|
    total *= n
  end
  total
end



# Factorial

# I worked on this challenge with John Paul Chaufman.

# Your Solution Below
def factorial(number)
if number <= 1
  1
  else

  (1..number).each.reduce(:*)
  puts "try 1"
  end
end

factorial(9)

def factorial(number)
  total = 1
  (1..number).each do |n|
  total *= n
  puts "try 2"
  end
  total
end
 factorial(11)

def factorial(number)
if number <= 1
  1
  else
  number.downto(1).reduce(:*)
  puts "try 3"
  end
end
 factorial(19)
def factorial(number)
  print "try 4"
  if number < 0
  return nil
  end
  if number <= 1
  1
  else
  factorial(number)

  end

end
 factorial(11)

factorial(11)







