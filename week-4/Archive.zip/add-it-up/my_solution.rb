# Add it up!

# Complete each step below according to the challenge directions and
# include it in this file. Also make sure everything that isn't code
# is commented in the file.

# I worked on this challenge [by myself, with: ].

# 0. total Pseudocode
# make sure all pseudocode is commented out!

# Input: An array of numbers, integers or floats.
# Output: A number, an interger or a float.
# Steps to solve the problem
# 0. White a method that accepts an array as argument and return and number
# Array methods we may use
# 1. mapping, getting, grabbing, every number contained in the array:
# ->  .map / .each / .reduce / .inject
# 2. Setting a variable for the total=0
# 3. Summing every element thanks to a method or using each to iterate over the array
# 4. printing / returning the total=integer or a float


# 2. total refactored solution
# return output
# array.each {|output,x| output += x }
# end


# 3. total refactored solution
def total(array)
  # array.reduce 0, :+
  # array.inject(:+)
  # array.map(&:to_i).reduce(:+)
  array.inject {|item_in_the_array,x| item_in_the_array+x}
  # puts array.each {|object,another_objects| print object + another_objects }
  # array.reduce(:+)
end


# 4. sentence_maker pseudocode
# Input: A single argument (a.k.a an array of strings (cf spec.rb))
# Output: A string (cf spec.rb)
# Steps to solve the problem.

# creating a variable items and counting (.count method) the number of objects (strings) in the arrays.
# creating a variable output and doign the following operations on it:
# -> .value_at method -> returns every value at the specific possition in the array with argument (0..(items-1)) in order to return the apropriate number of items contained in the a_single_argument array.
# -> .join with the (" ") argument in order to add the differents objects of the array in an only one string separated by as space.
# -> .capitaliza in order to have the first letter of the string capitalized.
# -> return the outpur variable followed by a "." ( + ".") in order to have a gramatically correct sentence.

# 1. total initial solution



# 5. sentence_maker initial solution
def sentence_maker(a_single_argument)
 items  = a_single_argument.count.to_i
 output = a_single_argument.values_at(0..(items-1)).join(" ").capitalize
 return output + "."
end



# 6. sentence_maker refactored solution
